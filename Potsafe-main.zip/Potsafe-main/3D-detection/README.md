
## How to run


### Setup the right environment 


```
$ git clone https://github.com/isl-org/MiDaS
$ cd MiDAS
$ virtualenv env
$ source env/bin/activate
$ pip install -r requirements.txt
```
### Run the file
```
$ python main.py
```
The desired file will be saved as **output.mp4**
